export default function Home() {
  return (
    <div style={{ fontFamily: "system-ui, -apple-system, Segoe UI, Roboto, sans-serif", padding: 24 }}>
      <h1 style={{ fontSize: 18, marginTop: 0 }}>form2chat-mvp</h1>
      <ul>
        <li><a href="/demo">Demo</a></li>
        <li><a href="/admin">Admin</a></li>
      </ul>
      <div style={{ fontSize: 12, opacity: 0.7 }}>Commands in chat: back, restart</div>
    </div>
  );
}
