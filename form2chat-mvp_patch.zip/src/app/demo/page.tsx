"use client";

import React, { useEffect, useMemo, useState } from "react";

type InputHint =
  | { type: "text" }
  | { type: "number" }
  | { type: "date" }
  | { type: "choice"; options: string[] }
  | { type: "file"; accept?: string };

type BotRes =
  | { kind: "ask"; sessionId: string; fieldId: string; message: string; input: InputHint; progress: { done: number; total: number } }
  | { kind: "review"; sessionId: string; message: string; answers: Record<string, any>; progress: { done: number; total: number } }
  | { kind: "done"; sessionId: string; message: string };

type Msg = { from: "bot" | "user"; text: string };

export default function DemoPage() {
  const formId = "demo";
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [text, setText] = useState("");
  const [bot, setBot] = useState<BotRes | null>(null);
  const [uploading, setUploading] = useState(false);

  const progressLabel = useMemo(() => {
    if (!bot || !("progress" in bot)) return "";
    return `${bot.progress.done}/${bot.progress.total}`;
  }, [bot]);

  async function postChat(payload: any) {
    const r = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    return (await r.json()) as BotRes;
  }

  async function init() {
    const r = await postChat({ formId });
    setSessionId(r.sessionId);
    setBot(r);
    setMsgs([{ from: "bot", text: r.message }]);
  }

  useEffect(() => {
    init();
  }, []);

  async function send() {
    if (!sessionId) return;
    const t = text.trim();
    if (!t) return;

    setMsgs((m) => [...m, { from: "user", text: t }]);
    setText("");

    const r = await postChat({ formId, sessionId, text: t });
    setBot(r);
    setMsgs((m) => [...m, { from: "bot", text: r.message }]);
  }

  async function uploadFile(file: File) {
    if (!sessionId || !bot || bot.kind !== "ask") return;
    if (bot.input.type !== "file") return;

    setUploading(true);
    try {
      const fd = new FormData();
      fd.append("file", file);

      const url = `/api/upload?formId=${encodeURIComponent(formId)}&sessionId=${encodeURIComponent(
        sessionId
      )}&fieldId=${encodeURIComponent(bot.fieldId)}`;
      const r = await fetch(url, { method: "POST", body: fd });
      const next = (await r.json()) as BotRes;

      setBot(next);
      setMsgs((m) => [
        ...m,
        { from: "user", text: `Uploaded: ${file.name}` },
        { from: "bot", text: next.message },
      ]);
    } finally {
      setUploading(false);
    }
  }

  async function submit() {
    if (!sessionId) return;
    const r = await fetch("/api/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ formId, sessionId }),
    });
    const next = (await r.json()) as BotRes;
    setBot(next);
    setMsgs((m) => [...m, { from: "bot", text: next.message }]);
  }

  return (
    <div
      style={{
        maxWidth: 720,
        margin: "24px auto",
        fontFamily: "system-ui, -apple-system, Segoe UI, Roboto, sans-serif",
      }}
    >
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 12 }}>
        <h1 style={{ fontSize: 18, margin: 0 }}>Form → Chat (Demo)</h1>
        <div style={{ fontSize: 12, opacity: 0.7 }}>{progressLabel}</div>
      </div>

      <div style={{ border: "1px solid #ddd", borderRadius: 12, padding: 12, minHeight: 420, background: "#fff" }}>
        {msgs.map((m, idx) => (
          <div key={idx} style={{ display: "flex", justifyContent: m.from === "user" ? "flex-end" : "flex-start", margin: "8px 0" }}>
            <div
              style={{
                maxWidth: "80%",
                padding: "10px 12px",
                borderRadius: 16,
                background: m.from === "user" ? "#111" : "#f2f2f2",
                color: m.from === "user" ? "#fff" : "#111",
                whiteSpace: "pre-wrap",
              }}
            >
              {m.text}
            </div>
          </div>
        ))}

        {bot?.kind === "review" && (
          <div style={{ marginTop: 14, padding: 12, border: "1px solid #eee", borderRadius: 12 }}>
            <div style={{ fontWeight: 600, marginBottom: 8 }}>Review</div>
            <pre style={{ margin: 0, fontSize: 12, background: "#fafafa", padding: 10, borderRadius: 8, overflowX: "auto" }}>
              {JSON.stringify(bot.answers, null, 2)}
            </pre>
            <button
              onClick={submit}
              style={{ marginTop: 10, padding: "10px 12px", borderRadius: 10, border: "1px solid #111", background: "#111", color: "#fff", cursor: "pointer" }}
            >
              Submit
            </button>
          </div>
        )}
      </div>

      <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
        {bot?.kind === "ask" && bot.input.type === "file" ? (
          <div style={{ flex: 1, display: "flex", gap: 8, alignItems: "center" }}>
            <input
              type="file"
              accept={bot.input.accept}
              disabled={uploading}
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) uploadFile(f);
                e.currentTarget.value = "";
              }}
            />
            <div style={{ fontSize: 12, opacity: 0.7 }}>{uploading ? "Uploading..." : ""}</div>
          </div>
        ) : bot?.kind === "ask" && bot.input.type === "choice" ? (
          <div style={{ flex: 1, display: "flex", flexWrap: "wrap", gap: 8 }}>
            {bot.input.options.map((o) => (
              <button
                key={o}
                onClick={() => setText(o)}
                style={{ padding: "8px 10px", borderRadius: 999, border: "1px solid #ddd", background: "#fff", cursor: "pointer" }}
              >
                {o}
              </button>
            ))}
          </div>
        ) : (
          <>
            <input
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") send();
              }}
              placeholder='Type your answer… (commands: "back", "restart")'
              style={{ flex: 1, padding: "10px 12px", borderRadius: 10, border: "1px solid #ddd" }}
            />
            <button
              onClick={send}
              style={{ padding: "10px 12px", borderRadius: 10, border: "1px solid #111", background: "#111", color: "#fff", cursor: "pointer" }}
            >
              Send
            </button>
          </>
        )}
      </div>

      <div style={{ marginTop: 10, fontSize: 12, opacity: 0.7 }}>
        View submissions at <a href="/admin">/admin</a>
      </div>
    </div>
  );
}
