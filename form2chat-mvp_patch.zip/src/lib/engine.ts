import { db, nowIso } from "./db";
import { loadForm, Field } from "./form";
import crypto from "crypto";

export type ChatResponse =
  | { kind: "ask"; sessionId: string; fieldId: string; message: string; input: InputHint; progress: { done: number; total: number } }
  | { kind: "review"; sessionId: string; message: string; answers: Record<string, any>; progress: { done: number; total: number } }
  | { kind: "done"; sessionId: string; message: string };

export type InputHint =
  | { type: "text" }
  | { type: "number" }
  | { type: "date" }
  | { type: "choice"; options: string[] }
  | { type: "file"; accept?: string };

function getSession(sessionId: string) {
  return db.prepare("SELECT * FROM sessions WHERE id = ?").get(sessionId) as any | undefined;
}

function upsertSession(sessionId: string, formId: string) {
  const s = getSession(sessionId);
  if (s) return s;
  db.prepare("INSERT INTO sessions (id, form_id, field_index, answers_json, status, updated_at) VALUES (?, ?, 0, '{}', 'in_progress', ?)")
    .run(sessionId, formId, nowIso());
  return getSession(sessionId)!;
}

function parseAnswers(json: string) {
  try { return JSON.parse(json || "{}"); } catch { return {}; }
}

function saveSession(sessionId: string, fieldIndex: number, answers: Record<string, any>, status: string = "in_progress") {
  db.prepare("UPDATE sessions SET field_index = ?, answers_json = ?, status = ?, updated_at = ? WHERE id = ?")
    .run(fieldIndex, JSON.stringify(answers), status, nowIso(), sessionId);
}

function hintForField(field: Field): InputHint {
  switch (field.type) {
    case "text": return { type: "text" };
    case "number": return { type: "number" };
    case "date": return { type: "date" };
    case "select":
    case "radio": return { type: "choice", options: field.options ?? [] };
    case "file": {
      const accept = field.validation?.allowedMime?.includes("application/pdf") ? "application/pdf" : undefined;
      return { type: "file", accept };
    }
  }
}

function validate(field: Field, raw: string): { ok: true; value: any } | { ok: false; error: string } {
  const required = !!field.required;

  if (field.type !== "file" && required && raw.trim() === "") {
    return { ok: false, error: "I need something here — can you enter a value?" };
  }

  if (field.type === "text") {
    if (field.validation?.kind === "email") {
      const v = raw.trim();
      const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
      if (!emailOk) return { ok: false, error: "That doesn’t look like an email. Can you try again?" };
      return { ok: true, value: v };
    }
    return { ok: true, value: raw.trim() };
  }

  if (field.type === "number") {
    const n = Number(raw);
    if (!Number.isFinite(n)) return { ok: false, error: "Can you enter a number?" };
    if (field.validation?.min != null && n < field.validation.min) return { ok: false, error: `Please enter a number ≥ ${field.validation.min}.` };
    if (field.validation?.max != null && n > field.validation.max) return { ok: false, error: `Please enter a number ≤ ${field.validation.max}.` };
    return { ok: true, value: n };
  }

  if (field.type === "date") {
    const t = Date.parse(raw);
    if (Number.isNaN(t)) return { ok: false, error: "Can you enter a date (or use the date picker)?" };
    return { ok: true, value: new Date(t).toISOString().slice(0, 10) };
  }

  if (field.type === "select" || field.type === "radio") {
    const options = field.options ?? [];
    const normalized = raw.trim().toLowerCase();

    const idx = Number(normalized);
    if (Number.isInteger(idx) && idx >= 1 && idx <= options.length) {
      return { ok: true, value: options[idx - 1] };
    }

    const match = options.find(o => o.toLowerCase() === normalized);
    if (!match) return { ok: false, error: `Pick one of: ${options.join(", ")}.` };
    return { ok: true, value: match };
  }

  return { ok: true, value: raw.trim() };
}

export function startOrContinue(formId: string, sessionId?: string): ChatResponse {
  const form = loadForm(formId);
  const sid = sessionId ?? crypto.randomUUID();
  const session = upsertSession(sid, formId);
  const answers = parseAnswers(session.answers_json);

  if (session.status === "submitted") {
    return { kind: "done", sessionId: sid, message: "This conversation is already submitted. Thanks!" };
  }

  const total = form.fields.length;
  const i = Number(session.field_index ?? 0);

  if (i >= total) {
    return { kind: "review", sessionId: sid, message: "Quick review — does everything look right?", answers, progress: { done: total, total } };
  }

  const field = form.fields[i];
  return {
    kind: "ask",
    sessionId: sid,
    fieldId: field.id,
    message: field.label,
    input: hintForField(field),
    progress: { done: i, total }
  };
}

export function handleUserMessage(formId: string, sessionId: string, userText: string): ChatResponse {
  const form = loadForm(formId);
  const session = upsertSession(sessionId, formId);
  const answers = parseAnswers(session.answers_json);
  const total = form.fields.length;
  let i = Number(session.field_index ?? 0);

  const cmd = userText.trim().toLowerCase();
  if (cmd === "restart") {
    saveSession(sessionId, 0, {}, "in_progress");
    return startOrContinue(formId, sessionId);
  }
  if (cmd === "back") {
    i = Math.max(0, i - 1);
    saveSession(sessionId, i, answers, "in_progress");
    return startOrContinue(formId, sessionId);
  }

  if (i >= total) {
    return { kind: "review", sessionId, message: "Quick review — does everything look right?", answers, progress: { done: total, total } };
  }

  const field = form.fields[i];
  if (field.type === "file") {
    return {
      kind: "ask",
      sessionId,
      fieldId: field.id,
      message: "Please upload the file using the upload button below.",
      input: hintForField(field),
      progress: { done: i, total }
    };
  }

  const v = validate(field, userText);
  if (!v.ok) {
    return {
      kind: "ask",
      sessionId,
      fieldId: field.id,
      message: v.error,
      input: hintForField(field),
      progress: { done: i, total }
    };
  }

  answers[field.id] = v.value;
  i = i + 1;
  saveSession(sessionId, i, answers, "in_progress");
  return startOrContinue(formId, sessionId);
}

export function recordFileAndAdvance(params: {
  formId: string;
  sessionId: string;
  fieldId: string;
  originalName: string;
  mime: string;
  sizeBytes: number;
  diskPath: string;
  fileId: string;
}): ChatResponse {
  const form = loadForm(params.formId);
  const session = upsertSession(params.sessionId, params.formId);
  const answers = parseAnswers(session.answers_json);
  const total = form.fields.length;
  let i = Number(session.field_index ?? 0);

  const expected = form.fields[i];
  if (!expected || expected.id !== params.fieldId || expected.type !== "file") {
    return startOrContinue(params.formId, params.sessionId);
  }

  db.prepare("INSERT INTO files (id, session_id, field_id, original_name, mime, size_bytes, disk_path) VALUES (?, ?, ?, ?, ?, ?, ?)")
    .run(params.fileId, params.sessionId, params.fieldId, params.originalName, params.mime, params.sizeBytes, params.diskPath);

  answers[params.fieldId] = {
    fileId: params.fileId,
    name: params.originalName,
    mime: params.mime,
    sizeBytes: params.sizeBytes
  };

  i = i + 1;
  saveSession(params.sessionId, i, answers, "in_progress");
  return startOrContinue(params.formId, params.sessionId);
}

export function submitSession(formId: string, sessionId: string): ChatResponse {
  const session = getSession(sessionId);
  if (!session) return { kind: "done", sessionId, message: "No active session found." };
  const answers = parseAnswers(session.answers_json);

  const submissionId = crypto.randomUUID();
  db.prepare("INSERT INTO submissions (id, session_id, form_id, answers_json) VALUES (?, ?, ?, ?)")
    .run(submissionId, sessionId, formId, JSON.stringify(answers));

  saveSession(sessionId, Number(session.field_index ?? 0), answers, "submitted");
  return { kind: "done", sessionId, message: "Submitted. Thank you!" };
}
