import fs from "fs";
import path from "path";

export type FieldType = "text" | "number" | "select" | "radio" | "date" | "file";

export type Field = {
  id: string;
  label: string;
  type: FieldType;
  required?: boolean;
  options?: string[];
  validation?: {
    kind?: "email";
    min?: number;
    max?: number;
    maxSizeMB?: number;
    allowedMime?: string[];
  };
};

export type FormSchema = {
  id: string;
  title: string;
  fields: Field[];
};

export function loadForm(formId: string): FormSchema {
  const p = path.join(process.cwd(), "forms", `${formId}.json`);
  const raw = fs.readFileSync(p, "utf-8");
  return JSON.parse(raw) as FormSchema;
}
