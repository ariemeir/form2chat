# form2chat-mvp patch

This zip contains only the files needed for the schema-driven form→chat demo.
It is meant to be UNZIPPED into the ROOT of an existing Next.js (App Router) project.

## Steps

1) Unzip into your project root (the folder that contains package.json)
2) Ensure deps:

   npm i better-sqlite3

3) Ensure folders exist:

   mkdir -p uploads forms

4) Run:

   npm run dev

## Routes
- /demo
- /admin
